<div class="bx-banner-top">
            <div class="container">
                <div class="row">
                    <div class="banner-topo">
                        <img class="img-responsive" src="<?= REQUIRE_PATH; ?>/assets/image/banner-landing.jpg" alt=""/>
                    </div>
                </div>
                <div class="desc-banner-top col-md-4 text-right">
                    <h2>
                        Cadastre-se e 
                        ganhe uma consultoria 
                        condominial gratuita
                    </h2>

                    <form class="form-banner-top">
                        <div class="form-group">                            
                            <input type="text" placeholder="NOME"/>
                            <div class="thumb-icon">
                                <img src="<?= REQUIRE_PATH; ?>/assets/image/icon-user-1.png" alt=""/>
                            </div>
                        </div>
                        <div class="form-group">                            
                            <input type="text" placeholder="E-MAIL"/>
                            <div class="thumb-icon">
                                <img src="<?= REQUIRE_PATH; ?>/assets/image/icon-envelope-1.png" alt=""/>
                            </div>
                        </div>
                        <div class="form-group">                            
                            <input type="text" placeholder="TELEFONE"/>
                            <div class="thumb-icon">
                                <img src="<?= REQUIRE_PATH; ?>/assets/image/icon-phone-1.png" alt=""/>
                            </div>
                        </div>
                        <div class="form-group">                            
                            <input type="submit" class="btn-top-enviar" value="ENVIAR"/>                            
                        </div>
                    </form>
                    <!--END FORM-->
                    <div class="bx-consulting">
                        <h2>A CONSULTORIA</h2>
                        <p>
                            Lorem ipsum dolor sit amet, consectetur adipisicing elit,
                            sed do eiusmod tempor incididunt ut labore et dolore 
                            magna aliqua. Ut enim ad minim veniam, quis nostrud
                            exercitation ullamco laboris nisi ut aliquip ex ea
                            commodo consequat. Duis aute irure dolor in reprehenderit
                            in voluptate velit esse cillum dolore eu fugiat nulla
                            pariatur. Excepteur sint occaecat cupidatat non proident,
                            sunt in culpa qui officia deserunt mollit anim id est
                            laborum. Sed ut perspiciatis unde omnis iste natus error
                            sit voluptatem accusantium doloremque laudantium, totam 
                            rem aperiam, eaque ipsa quae ab illo.
                        </p>
                    </div>
                    <!-- END CONSULTING -->
                </div>
            </div>
        </div>
        <!-- END BANNER TOP -->
        <section class="sec-info-olimpo">
            <div class="content">
                <div class="bx-info">
                    <div class="logo-info">
                        <img class="img-responsive" src="<?= REQUIRE_PATH; ?>/assets/image/logo-info.png" alt="logo"/>
                    </div>
                    <div class="desc-logo-info">
                        <p>
                            Fundada em 1998 e com profundas raízes em Brasília/DF, a Olimpo Construtora é uma empresa especializada em “Restauração de Patologias da Construção Civil” em obras de Condomínios 
                        </p>
                    </div>
                </div>
                <div class="bx-info">
                    <div class="thumb-info">
                        <img class="img-thumbnail" src="<?= REQUIRE_PATH; ?>/assets/image/thumb-info.jpg" alt=""/>
                    </div>
                </div>
            </div> 
            <div class="clear"></div> 
        </section>
        <!--END PROJECTS-->
        <section class="sec-project">
            <div class="bg-image-project">
                <img class="img-responsive" src="<?= REQUIRE_PATH; ?>/assets/image/bg-novos-project.jpg" alt=""/>            
                <div class="title-our-project">
                    <h2>Nossos Projetos</h2>
                </div>            
            </div>
            <div class="bx-grid-thumb">
                <div class="bg-grid-thumb">
					
                        <div class="grid-thumb">
                            <img src="<?= REQUIRE_PATH; ?>/assets/image/1-3.jpg" alt=""/>
                        </div>
					
					 <div class="grid-thumb">
                            <img src="<?= REQUIRE_PATH; ?>/assets/image/2-2.jpg" alt=""/>
                        </div>
					
					<div class="grid-thumb">
                            <img src="<?= REQUIRE_PATH; ?>/assets/image/3-1.jpg" alt=""/>
                        </div>
					
					<div class="grid-thumb">
                            <img src="<?= REQUIRE_PATH; ?>/assets/image/4-1.jpg" alt=""/>
                        </div>
					
					<div class="grid-thumb">
                            <img src="<?= REQUIRE_PATH; ?>/assets/image/5-1.jpg" />
                        </div>
					
					<div class="grid-thumb">
                          <img src="<?= REQUIRE_PATH; ?>/assets/image/6-2.jpg">
                        </div>
					
					<div class="grid-thumb">
                          <img src="<?= REQUIRE_PATH; ?>/assets/image/7-1.jpg">
                        </div>
					
					<div class="grid-thumb">
                          <img src="<?= REQUIRE_PATH; ?>/assets/image/8.jpg">
                        </div>
					
					<div class="grid-thumb">
                          <img src="<?= REQUIRE_PATH; ?>/assets/image/9.jpg">
                        </div>
                       
					
					
					
                    <div class="clear"></div>
                </div>
            </div>
            <!--END GRID-->
        </section>
        <!--END GRID PROJECTS-->
        <section class="sec-consulting">
            <div class="content">
                <div class="block-consulting">
                    <h2>
                        Cadastre-se e 
                        ganhe uma consultoria 
                        condominial gratuita
                    </h2>
                </div>
                <!--END INFORMATION REGISTRATION-->
                <div class="block-consulting">
                    <form class="form-registration">
                        <div class="field-input">        
                            <input type="text" placeholder="NOME"/>
                            <div class="icon-field">
                                <img src="<?= REQUIRE_PATH; ?>/assets/image/icon-user-1.png" alt=""/>
                            </div>
                        </div>
                        <div class="field-input">        
                            <input type="text" placeholder="E-MAIL"/>
                            <div class="icon-field">                               
                                <img src="<?= REQUIRE_PATH; ?>/assets/image/icon-envelope-1.png" alt=""/>
                            </div>
                        </div>
                        <div class="field-input">        
                            <input type="text" placeholder="TELEFONE"/>
                            <div class="icon-field">
                                <img src="<?= REQUIRE_PATH; ?>/assets/image/icon-phone-1.png" alt=""/>
                            </div>
                        </div>
                        <div class="field-btn-consulting">
                            <input type="submit" class="btn-consulting" value="ENVIAR"/>
                        </div>
                    </form>
                </div>
                <!--END FORM REGISTRATION-->
            </div>
        </section>
        <!--END REGISTRATION CONSULTING-->